package sl1_pro;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author lenovo
 */
public class SL1_pro { 
public static String value ;
public static String id;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        main_dashboard flag = new main_dashboard();
        flag.setVisible(true);
    }
    
}
